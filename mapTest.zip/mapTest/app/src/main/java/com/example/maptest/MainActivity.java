package com.example.maptest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.api.Status;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.AutocompleteActivity;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import java.io.InputStream;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    TextView textView1;
    TextView textView2;
    TextView textView3,textView4,textView5,textView6,textView7;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText= findViewById(R.id.edit_text);
        textView1=findViewById(R.id.text_view1);
        textView2=findViewById(R.id.text_view2);
        textView3=findViewById(R.id.textView3);
        textView4=findViewById(R.id.textView4);
        textView5=findViewById(R.id.textView5);
        textView6=findViewById(R.id.textView6);
        textView7=findViewById(R.id.textView7);
        Button btnBack=findViewById(R.id.btnBack);
        Button btnCheckout=findViewById(R.id.btnCheckout);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myResults = new Intent( MainActivity.this,Cart_Activity.class);
                startActivity(myResults);
            }
        });

        btnCheckout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                /*String addressFinal=textView3.toString()+textView4.toString()+textView5.toString()+textView6.toString();
               Bundle bundle = new Bundle();
                bundle.putString("Address",addressFinal);*/
                Intent myResults = new Intent( MainActivity.this,Checkout_Activity.class);
                startActivity(myResults);

            }
        });

        Places.initialize(getApplicationContext(),"AIzaSyCZdXirItz3j-7eAdqPSksroSLpBESF3U0");
        editText.setFocusable(false);
        editText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                List<Place.Field> fieldList = Arrays.asList(Place.Field.ADDRESS,Place.Field.LAT_LNG,Place.Field.NAME);
                Intent intent= new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY,fieldList).build(MainActivity.this);
                startActivityForResult(intent,100);
            }
        });



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==100 && resultCode==RESULT_OK)
        {
            Place place=Autocomplete.getPlaceFromIntent(data);
            editText.setText(place.getAddress());
            //textView1.setText(String.format("Locality Name : %s",place.getName()));
            //textView2.setText(String.valueOf(place.getLatLng()));
            String address=place.getAddress();
            String[] array1 = address.split(",",0);
            textView3.setText(array1[0]);
            textView4.setText(array1[1]);
            textView5.setText(array1[2]);
            textView6.setText(array1[3]);


        }else if(resultCode== AutocompleteActivity.RESULT_ERROR)
        {
            Status status=Autocomplete.getStatusFromIntent(data);
            Toast.makeText(getApplicationContext(),status.getStatusMessage(),Toast.LENGTH_SHORT).show();

        }

    }

}