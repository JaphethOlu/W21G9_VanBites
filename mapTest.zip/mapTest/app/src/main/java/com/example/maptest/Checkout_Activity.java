package com.example.maptest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.gson.internal.$Gson$Preconditions;

public class Checkout_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout_);

        TextView address=findViewById(R.id.address);
        EditText delivery=findViewById(R.id.delivery);
        EditText promo=findViewById(R.id.promo);
        Button goCart=findViewById(R.id.goToCart);
        Button confirm=findViewById(R.id.CheckOrder);

        goCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myResults = new Intent( Checkout_Activity.this,Cart_Activity.class);
                startActivity(myResults);
            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myResults = new Intent( Checkout_Activity.this,Confirm_Activity.class);
                startActivity(myResults);
            }
        });

    }
}